
# Network Traffic Analysis Project

## 📄 Project Overview

This project involved capturing, analyzing, and interpreting network traffic to identify potential security threats, suspicious activity, and system misconfigurations. By using packet analysis tools, various network events were inspected for signs of reconnaissance, unauthorized access attempts, and data exfiltration.

---

## 🎯 Objectives

- Capture real-time network traffic in a controlled lab environment.
- Analyze common protocols such as **HTTP**, **DNS**, and **TCP**.
- Detect evidence of scanning, brute force attempts, and data leakage.
- Develop a report with identified threats and mitigation strategies.

---

## 🔧 Tools & Technologies Used

| Tool/Technology | Purpose |
|---|---|
| **Wireshark** | Packet capture and analysis |
| **tcpdump** | Command-line traffic capture |
| **Kali Linux** | Traffic generation through simulated attacks |
| **Nmap** | External scanning to generate sample traffic |
| **Scapy (Python)** | Custom packet generation (optional) |

---

## 🔬 Key Findings

| Finding | Description | Severity |
|---|---|---|
| Port Scan Detection | Multiple SYN packets from external IPs | 🔴 High |
| Unencrypted HTTP Credentials | Login form transmitted in plaintext | 🔴 High |
| Suspicious DNS Queries | Unusually high volume from one device | 🟠 Medium |
| ARP Spoofing | Duplicate IP addresses detected via ARP traffic | 🟠 Medium |
| Excessive Failed SSH Logins | Possible brute force attempt detected | 🟠 Medium |

---

## 📂 Files in This Project

| File | Description |
|---|---|
| `traffic-sample.pcap` | Raw network traffic capture file (openable in Wireshark) |
| `wireshark-analysis-report.pdf` | Full PDF report documenting analysis and findings |
| `screenshot-wireshark.png` | Screenshot of Wireshark capturing and analyzing traffic |

---

## 📸 Sample Screenshots

### Wireshark Capturing Suspicious Traffic
![Wireshark Capture](./screenshot-wireshark.png)

---

## 📝 Sample Analysis Process

### 1. Traffic Capture
```bash
sudo tcpdump -i eth0 -w traffic-sample.pcap
```
Captured all network traffic on **interface eth0** and saved it to a PCAP file for analysis.

### 2. Protocol Filtering in Wireshark
Filtered specific traffic for analysis, such as:
- HTTP traffic (`http`)
- SSH traffic (`tcp.port == 22`)
- Suspicious DNS queries (`dns`)

### 3. Threat Detection
- **Port Scan Detection:** Multiple SYN packets with no follow-up (common in Nmap scans).
- **Unencrypted HTTP Login:** Credentials visible in clear text.
- **Unusual DNS Queries:** Continuous outbound DNS requests to unknown domains.

---

## 📑 Recommendations

- ✅ **Enable encryption** (HTTPS, SSH) for all sensitive traffic.
- ✅ **Implement network segmentation** to isolate critical systems.
- ✅ **Deploy Intrusion Detection Systems (IDS)** to monitor for scanning and attacks.
- ✅ **Restrict outbound DNS queries** to trusted domains.
- ✅ **Harden authentication mechanisms** and limit SSH access to known IPs.
- ✅ **Conduct regular network audits** to identify anomalies and misconfigurations.

---

## 📌 References

- [Wireshark User Documentation](https://www.wireshark.org/docs/)
- [SANS Network Traffic Analysis Poster](https://www.sans.org/security-resources/posters/network-traffic-analysis/)

---

## 👤 Author

**Edmond Degand**  
- [LinkedIn](https://linkedin.com/in/edmonddegand)  
- [Email](mailto:edmonddeg@gmail.com)

---
